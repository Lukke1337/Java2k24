package org.pjatk.homework.zad04;

import java.util.Scanner;

public class NonStandardSumProgram {

    /*
        Użytkownik wprowadza z klawiatury dwie liczby całkowite.
        Napisz program obliczający sumę tych liczb, korzystając
        z operatorów inkrementacji (++) i dekrementacji (--).
        Użycie operatora dodawania (+) jest zabronione.
     */
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Podaj pierwszą liczbę całkowitą: ");
        int pierwszaLiczba = scanner.nextInt();

        System.out.print("Podaj drugą liczbę całkowitą: ");
        int drugaLiczba = scanner.nextInt();

        // Zastosowanie operatorów inkrementacji i dekrementacji zamiast operatora dodawania
        while (pierwszaLiczba > 0) {
            pierwszaLiczba--;
            drugaLiczba++;
        }

        while (pierwszaLiczba < 0) {
            pierwszaLiczba++;
            drugaLiczba--;
        }

        System.out.println("Suma: " + drugaLiczba);
    }
}
