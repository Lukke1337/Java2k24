package org.pjatk.homework.zad03;

import java.util.Scanner;

public class RingFieldProgram {

    /*
        Napisz program obliczający pole powierzchni pierścienia kołowego
        o promieniu zewnętrznym R i wewnętrznym r. Długości promieni użytkownik
        wprowadza z klawiatury. Program powinien zasygnalizować błędne dane
        i ponownie zapytać o potrzebną wartość.
     */
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double R, r;

        do {
            System.out.print("Podaj promień zewnętrzny (R) pierścienia: ");
            while (!scanner.hasNextDouble()) {
                System.out.println("To nie jest poprawna wartość. Podaj liczbę.");
                scanner.next(); // odrzucenie błędnej wartości
            }
            R = scanner.nextDouble();

            System.out.print("Podaj promień wewnętrzny (r) pierścienia: ");
            while (!scanner.hasNextDouble()) {
                System.out.println("To nie jest poprawna wartość. Podaj liczbę.");
                scanner.next(); // odrzucenie błędnej wartości
            }
            r = scanner.nextDouble();

            if (R <= r) {
                System.out.println("ERROR: Promień zewnętrzny (R) musi być większy od promienia wewnętrznego (r).");
            }
        } while (R <= r);

        double polePierscienia = Math.PI * (R * R - r * r);
        System.out.println("Pole powierzchni pierścienia: " + polePierscienia);
    }
}
