package org.pjatk.homework.zad06;

import java.util.Scanner;

/*
    Napisz program który sprawdzi, czy wprowadzone zdanie
    jest palindromem, czyli brzmi tak samo czytane od strony lewej do prawej
    i od prawej do lewej.
    Przykład zdania-palindromu jest 'Kobyła ma mały bok' (bez rozróźniania wielkości
    liter i uwzględniania odstępów miezy słowami)
 */
public class PalindromProgram {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Podaj zdanie do sprawdzenia: ");
        String zdanie = scanner.nextLine().toLowerCase().replaceAll("\\s+", "");

        boolean czyPalindrom = true;
        int dlugosc = zdanie.length();

        for (int i = 0; i < dlugosc / 2; i++) {
            if (zdanie.charAt(i) != zdanie.charAt(dlugosc - i - 1)) {
                czyPalindrom = false;
                break;
            }
        }

        if (czyPalindrom) {
            System.out.println("Podane zdanie jest palindromem.");
        } else {
            System.out.println("Podane zdanie nie jest palindromem.");
        }
    }

}
