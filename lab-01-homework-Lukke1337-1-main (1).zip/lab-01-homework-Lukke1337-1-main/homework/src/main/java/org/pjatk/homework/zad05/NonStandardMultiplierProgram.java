package org.pjatk.homework.zad05;

import java.util.Scanner;

/*
    Napisz program obliczający iloczyn dowolnej pary
    liczb całkowitych, nie korzystając z operatora *.
    Do dyspozycji masz operatory + i --.
 */
public class NonStandardMultiplierProgram {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Podaj pierwszą liczbę całkowitą: ");
        int pierwszaLiczba = scanner.nextInt();

        System.out.print("Podaj drugą liczbę całkowitą: ");
        int drugaLiczba = scanner.nextInt();

        int iloczyn = 0;

        for (int i = 0; i < Math.abs(drugaLiczba); i++) {
            iloczyn += pierwszaLiczba;
        }

        if (drugaLiczba < 0) {
            iloczyn = -iloczyn;
        }

        System.out.println("Iloczyn: " + iloczyn);
    }
}
