package org.pjatk.homework.zad02;

import java.util.Scanner;

public class SimpleSummingProgram {

    /*
        Użytkownik wprowadza z klawiatury serię liczb różnych od zero,
        zero natomiast jest sygnałem zakończenia wprowadzania danych.
        Napisz program, który obliczy sumę tych liczb
     */
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        double suma = 0;

        System.out.println("Wprowadzaj liczby (wprowadź 0 aby zakończyć):");

        double liczba;
        do {
            liczba = scanner.nextDouble();
            suma += liczba;
        } while (liczba != 0);

        System.out.println("Suma podanych liczb: " + suma);
    }
}
