# POJ_lab01-homework

Przykłady niektórych zadań są wzięte ze zbioru zadań.

Wiesław Rychlicki, "Programowanie w języku JAVA. Zbiór zadań z (p)odpowiedziami", Helion, 2012