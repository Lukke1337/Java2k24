package com.pjatk.example.mathutils;

public class MathUtils {
    /*
        Funkcja oblicza n!
     */


    public static int factorial(int n) {
        //
        int result = 1;
        for (int i = 1; i <= n; i++)
            result *= i;  //result = result * i
        return result;
        //
    }

    /*
        Funkcja oblicza n! (zastosować rekurencję)
     */
    public static int factorialRecursive(int n){
        //
        if(n==1) return 1;
        return n * factorialRecursive(n-1);
        //
        //return -1;
    }

    /*
        Funkcja oblicza przyblożoną całkę oznaczoną od a do b dla wielomiany o podanych w tabeli współczunnikach
        (całka oznaczona to pole powierzchni pod wykresem wielomianu na przedziale [a,b])
     */
    public static double integralOfPolynomial(double[] coefficients,double a, double b){

        double result=0;
        double x,y;
        for (int i=1;i < coefficients.length; i++){
            x+=coefficients[i]*Math.pow(a,i+1)/(i+1);
            y+=coefficients[i]*Math.pow(b,i+1)/(i+1);

        }
        return y-x;
    }

    /*
        Funkcja przedstawia nieskracalny ułamek w postaci a/b
        np. dla 9/12 zwróci "3/4"
                15/5 zwróci "3"
     */
    public static String simplifyFractionInString(int meter, int denominator) {

//            while (meter != denominator){ // dopóki dwie liczby nie są sobie równe
//                if (meter > denominator) {  // sprawdzamy, która z nich jest większa
//
//                    meter = meter - denominator; // odejmujemy mniejszą liczbę od wiekszej
//                } else {
//                    denominator = denominator - meter;
//                }
//            }
        int nwd = nwd(meter, denominator);
        meter /=nwd;            // meter = meter / nwd
        denominator /=nwd;      // denominator = denominator / nwd
        if(denominator == 1) return meter + "";
        return meter+"/"+denominator;

        }
        static int nwd(int a, int b){
            while (b != 0){
                int tmp = b;
                b = a % b;
                a = tmp;
            }
            return a;
        }
    }
