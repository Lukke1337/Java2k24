public class Zadanie1 {
    // Pola klasy reprezentujące pojemności butelek wody
    private int large = 2;
    private int medium = 1;
    private double small = 0.5;

    // Pola klasy reprezentujące ilość każdego rodzaju butelek wody
    private int LargeBottles = 0;
    private int MediumBottles = 0;
    private int SmallBottles = 0;

    // Metoda dodająca do zapasu określoną liczbę dużych butelek wody
    void addLarge(int num) {
        LargeBottles += num;
    }

    // Metoda dodająca do zapasu określoną liczbę średnich butelek wody
    void addMedium(int num) {
        MediumBottles += num;
    }

    // Metoda dodająca do zapasu określoną liczbę małych butelek wody
    void addSmall(int num) {
        SmallBottles += num;
    }

    // Metoda zwracająca łączną pojemność zgromadzonej wody
    double getTotalCapacity() {
        return (LargeBottles * large) + (MediumBottles * medium) + (SmallBottles * small);
    }

    // Metoda wypisująca stan zapasu wody
    void printStatus() {
        System.out.println(getTotalCapacity() + " litrow wody");
        System.out.println("Dużych butelek: " + LargeBottles);
        System.out.println("Średnich butelek: " + MediumBottles);
        System.out.println("Małych butelek: " + SmallBottles);
    }
}