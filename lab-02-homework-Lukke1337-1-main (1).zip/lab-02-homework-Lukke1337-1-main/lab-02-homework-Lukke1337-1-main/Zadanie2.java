import java.util.Scanner;

// Definicja klasy Zadanie2
class Zadanie2 {
    // Pola klasy reprezentujące szerokość i wysokość pudełka
    private int width;
    private int height;

    // Konstruktor klasy Zadanie2
    public Zadanie2(int width, int height) {
        this.width = width;
        this.height = height;
    }

    // Metoda łącząca pudełka diagonalnie
    public static Zadanie2 joinDiagonal(Zadanie2 box1, Zadanie2 box2) {
        int newWidth = box1.width + box2.width;
        int newHeight = box1.height + box2.height;
        return new Zadanie2(newWidth, newHeight);
    }

    // Metoda łącząca pudełka poziomo
    public static Zadanie2 joinHorizontal(Zadanie2 box1, Zadanie2 box2) {
        int newWidth = box1.width + box2.width;
        int newHeight = Math.max(box1.height, box2.height);
        return new Zadanie2(newWidth, newHeight);
    }

    // Metoda łącząca pudełka pionowo
    public static Zadanie2 joinVertical(Zadanie2 box1, Zadanie2 box2) {
        int newWidth = Math.max(box1.width, box2.width);
        int newHeight = box1.height + box2.height;
        return new Zadanie2(newWidth, newHeight);
    }

    // Metoda wypisująca rozmiar pudełka
    public void printSize() {
        System.out.println("Pudełko: (" + width + ", " + height + ")");
    }
}

