import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {

    // ZADANIE1
    public static void main(String[] args) {

        System.out.println("Zadanie 1");
        System.out.println(" ");
        // Tworzymy obiekt klasy Zadanie1
        Zadanie1 Zadanie1 = new Zadanie1();

        // Dodajemy różne liczby butelek wody do zapasu
        Zadanie1.addLarge(1);
        Zadanie1.addMedium(3);
        Zadanie1.addSmall(5);

        // Stan zapasu wody
        Zadanie1.printStatus();


        // ZADANI2

        // Tworzymy obiekt klasy Scanner do pobierania danych od użytkownika
        Scanner scanner = new Scanner(System.in);

        System.out.println("Zadanie2:");
        System.out.println(" ");
        // Pobieramy od użytkownika liczbę szerokości pudełek
        System.out.println("Podaj liczbę szerokości pudełek:");
        int numBoxes = scanner.nextInt();

        // Tworzymy tablicę pudełek o zadanych rozmiarach
        Zadanie2[] boxes = new Zadanie2[numBoxes];
        for (int i = 0; i < numBoxes; i++) {
            int width = i + 1; // szerokość pudełka
            int height = width * 2; // wysokość pudełka
            boxes[i] = new Zadanie2(width, height); // tworzenie obiektu pudełka i dodanie do tablicy
        }

        // Wyświetlamy rozmiary każdego z pudełek
        for (Zadanie2 box : boxes) {
            box.printSize();
        }

        // Łączymy pudełka w kombinacje diagonalne, wertykalne i horyzontalne i wyświetlamy ich rozmiary
        for (int i = 0; i < numBoxes - 1; i++) {
            Zadanie2 diagonalBox = Zadanie2.joinDiagonal(boxes[i], boxes[i + 1]);
            Zadanie2 horizontalBox = Zadanie2.joinHorizontal(boxes[i], boxes[i + 1]);
            Zadanie2 verticalBox = Zadanie2.joinVertical(boxes[i], boxes[i + 1]);

            System.out.println("Połączone pudełko diagonalnie:");
            diagonalBox.printSize();

            System.out.println("Połączone pudełko poziomo:");
            horizontalBox.printSize();

            System.out.println("Połączone pudełko pionowo:");
            verticalBox.printSize();
        }
    }
}